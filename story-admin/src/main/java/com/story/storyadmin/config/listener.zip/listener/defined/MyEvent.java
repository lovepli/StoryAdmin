package com.story.storyadmin.config.listener.defined;

import com.story.storyadmin.domain.entity.sysmgr.User;
import org.springframework.context.ApplicationEvent;

/**
 * 自定义事件
 * 自定义事件需要继承 ApplicationEvent 对象，在事件中定义一个 User 对象来模拟数据，构造方法中将 User 对象传进来初始化。
 * @author shengwu ni
 * @date 2018/07/05
 */
public class MyEvent extends ApplicationEvent {

    private User user;

    public MyEvent(Object source, User user) {
        super(source);
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}