package com.story.storyadmin.redis.session.config;

import org.springframework.context.annotation.Configuration;
//import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * Description:
 *
 * @author Lvshen
 * @version 1.0
 * @date: 2020/5/14 20:52
 * @since JDK 1.8
 */
//@Configuration
//@EnableRedisHttpSession
public class SessionConfiguration {
}
