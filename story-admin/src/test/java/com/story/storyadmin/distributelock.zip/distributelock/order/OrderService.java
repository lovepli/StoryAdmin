package com.story.storyadmin.distributelock.order;

/**
 * Description:
 *
 * @author Lvshen
 * @version 1.0
 * @date: 2020/3/15 23:43
 * @since JDK 1.8
 */
public interface OrderService {

    public void createOrder();
}
