package com.story.storyadmin.generictest.demo3;

/**
 * @author: lipan
 * @date: 2020-04-26
 * @description:
 */
public class Test {


}
