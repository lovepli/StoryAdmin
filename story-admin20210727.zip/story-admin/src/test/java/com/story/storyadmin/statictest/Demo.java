package com.story.storyadmin.statictest;

/**
 * @author: lipan
 * @date: 2020/6/4
 * @description: static 关键字可用于变量、方法、代码块和内部类，表示某个特定的成员只属于某个类本身，而不是该类的某个对象。
 */
public class Demo {
}
