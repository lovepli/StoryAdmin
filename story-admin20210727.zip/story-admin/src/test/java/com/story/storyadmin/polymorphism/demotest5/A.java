package com.story.storyadmin.polymorphism.demotest5;

/**
 * @author: lipan
 * @date: 2020-04-09
 * @description:
 */
public interface A {
}
