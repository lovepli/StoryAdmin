package com.story.storyadmin.config;
import com.story.storyadmin.config.threadpool.VisiableThreadPoolTaskExecutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author: 59688
 * @date: 2021/7/12
 * @description:  自定义线程池配置类，替代springboot默认线程池
 *
 *  默认情况下，在创建了线程池后，线程池中的线程数为0，当有任务来之后，就会创建一个线程去执行任务，
 *	当线程池中的线程数目达到corePoolSize后，就会把到达的任务放到缓存队列当中；
 *  当队列满了，就继续创建线程，当线程数量大于等于maxPoolSize后，开始使用拒绝策略拒绝
 */
@Configuration
//@EnableAsync //需要在Spring启动类上添加注解@EnableAsyn或者在你们线程池配置类添加@EnableAsyn
public class ThreadPoolConfig {

    /** 核心线程数（默认线程数） */
    @Value("${thread.pool.corePoolSize:15}")
    private int corePoolSize;

    /** 最大线程数 */
    @Value("${thread.pool.maxPoolSize:50}")
    private int maxPoolSize;

    /** 缓冲队列大小 */
    @Value("${thread.pool.queueCapacity:200}")
    private int queueCapacity;

    /** 允许线程空闲时间（单位：默认为秒） */
    @Value("${thread.pool.keepAliveSeconds:30000}")
    private int keepAliveSeconds;

    /** 线程名前缀 */
    @Value("${thread.pool.threadNamePrefix:async-service-}")
    private String threadNamePrefix;


    //将ThreadPoolTaskExecutor做为一个bean，通过spring的注入，保证只会初始化一次。
    @Bean("taskExecutor") // bean的名称，默认为首字母小写的方法名
    public ThreadPoolTaskExecutor  taskExecutor() {
        //ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        //在这里修改,实现对线程池的监控，方便查看
        ThreadPoolTaskExecutor executor = new VisiableThreadPoolTaskExecutor();
        //配置核心线程数
        executor.setCorePoolSize(corePoolSize);
        //配置最大线程数
        executor.setMaxPoolSize(maxPoolSize);
        //配置队列大小
        executor.setQueueCapacity(queueCapacity);
        executor.setKeepAliveSeconds(keepAliveSeconds);
        //配置线程池中的线程的名称前缀
        executor.setThreadNamePrefix(threadNamePrefix);
        // rejection-policy线程池对拒绝任务的处理策略:pool已经达到max size的时候，如何处理新任务?
        // CallerRunsPolicy：不在新线程中执行任务，而是由调用者所在的线程来执行。【由调用线程（提交任务的线程）处理该任务】
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        //executor.setWaitForTasksToCompleteOnShutdown(true);
        // 初始化
        executor.initialize();
        return executor;
    }
}
