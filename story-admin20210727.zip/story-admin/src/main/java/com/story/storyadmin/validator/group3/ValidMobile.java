package com.story.storyadmin.validator.group3;

public interface ValidMobile {
}
