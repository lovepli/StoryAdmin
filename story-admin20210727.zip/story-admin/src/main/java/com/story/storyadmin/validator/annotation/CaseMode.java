package com.story.storyadmin.validator.annotation;

/**
 * @author: 59688
 * @date: 2021/7/16
 * @description: 属性枚举
 */
public enum CaseMode {
    UPPER,
    LOWER;
}
