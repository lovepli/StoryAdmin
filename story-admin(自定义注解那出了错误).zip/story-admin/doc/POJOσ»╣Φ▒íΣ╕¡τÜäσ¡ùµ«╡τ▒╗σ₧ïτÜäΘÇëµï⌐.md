java POJO中 Integer 和 int 的不同,用int还是用Integer 
https://www.cnblogs.com/hanby/p/14450640.html

java int integer 选择_springboot~Integer和int如何选择，Integer的意义何在
https://blog.csdn.net/weixin_32251071/article/details/114140707

java pojo属性,java中的POJO类属性建议使用包装数据类型
https://blog.csdn.net/weixin_39824801/article/details/115995603

Oracle实现boolean类型的两个方法
https://blog.csdn.net/aguu125/article/details/84127236

java 小数类型选择 ：float,double 和Bigdecimal
https://blog.csdn.net/aguu125/article/details/84464371

Java实体类的属性类型与数据库表字段类型对应表
https://blog.csdn.net/lyhjava/article/details/50562786