package com.story.storyadmin.mapper.wind;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.story.storyadmin.domain.entity.wind.DictGroup;

public interface DictGroupMapper extends BaseMapper<DictGroup> {
}
