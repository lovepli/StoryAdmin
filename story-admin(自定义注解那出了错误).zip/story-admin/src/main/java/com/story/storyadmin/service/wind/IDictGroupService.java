package com.story.storyadmin.service.wind;

import com.baomidou.mybatisplus.extension.service.IService;
import com.story.storyadmin.domain.entity.wind.DictGroup;

public interface IDictGroupService extends IService<DictGroup> {
}
