package com.story.storyadmin.service.children;

import com.baomidou.mybatisplus.extension.service.IService;
import com.story.storyadmin.domain.entity.children.DDept;


/**
 * @author: 59688
 * @date: 2021/7/9
 * @description:
 */
public interface DDeptService  extends IService<DDept> {
}
