package com.story.storyadmin.service.tool;

import com.story.storyadmin.domain.entity.tool.Todo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 待办事项 服务类
 * </p>
 *
 * @author sunnj
 * @since 2019-08-14
 */
public interface TodoService extends IService<Todo> {

}
