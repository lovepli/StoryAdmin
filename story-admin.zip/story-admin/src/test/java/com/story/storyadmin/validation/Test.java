package com.story.storyadmin.validation;

/**
 * @author: lipan
 * @date: 2020/5/20
 * @description:
 */
public class Test {
}
