<template>
  <div class="public-net-disk">
    <Files personal="0" />
  </div>
</template>

<script>
import Files from '@/components/oa_sys/Files';

export default {
  name: 'PublicNetDisk', // 公共网盘
  components: {
    Files
  }
};
</script>

<style scoped>
</style>
