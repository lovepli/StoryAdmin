export { default } from './BaseTable2';
