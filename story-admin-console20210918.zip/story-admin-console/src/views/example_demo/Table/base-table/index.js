export { default } from './BaseTable';
