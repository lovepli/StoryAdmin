export { default } from './PdfBase64';
