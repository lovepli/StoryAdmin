export { default } from './Blank';
