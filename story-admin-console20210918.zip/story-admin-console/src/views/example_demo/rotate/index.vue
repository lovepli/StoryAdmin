<template>
  <div>
    <Rotate />
  </div>
</template>

<script>
import Rotate from '@/components/example_demo/rotate.vue'
export default {
  name: 'RotateOrangination',
  components: {
    Rotate
  }
}
</script>
