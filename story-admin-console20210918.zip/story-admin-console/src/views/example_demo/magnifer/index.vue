<template>
  <div>
    <magnifier />
  </div>
</template>

<script>
import Magnifier from '@/components/example_demo/magnifier.vue';
export default {
  name: 'Magnifying',
  components: {
    Magnifier
  }
};
</script>
