export { default } from './AMap';
