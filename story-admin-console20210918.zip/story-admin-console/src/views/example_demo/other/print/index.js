export { default } from './Print'
