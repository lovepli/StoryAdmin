export { default } from './FileToBase64';
