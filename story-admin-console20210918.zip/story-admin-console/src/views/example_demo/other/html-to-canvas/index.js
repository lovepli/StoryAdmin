export { default } from './HtmlToCanvas';
