export { default } from './BarChart';
