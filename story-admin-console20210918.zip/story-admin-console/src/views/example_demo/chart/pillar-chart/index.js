export { default } from './PillarChart';
