export { default } from './AreaChart';
