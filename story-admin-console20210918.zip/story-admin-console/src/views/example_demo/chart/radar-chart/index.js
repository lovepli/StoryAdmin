export { default } from './RadarChart';
