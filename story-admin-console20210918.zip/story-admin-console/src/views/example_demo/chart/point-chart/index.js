export { default } from './PointChart';
