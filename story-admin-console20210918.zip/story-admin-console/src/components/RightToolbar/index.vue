<!-- @author Shiyn/   huangmx 20200807优化-->
<template>
  <div class="top-right-btn">
    <el-row>
      <el-tooltip :content="showSearch ? '隐藏搜索' : '显示搜索'" class="item" effect="dark" placement="top">
        <el-button size="mini" circle icon="el-icon-search" @click="toggleSearch()" />
      </el-tooltip>
      <el-tooltip class="item" effect="dark" content="刷新" placement="top">
        <el-button size="mini" circle icon="el-icon-refresh" @click="refresh()" />
      </el-tooltip>
    </el-row>
  </div>
</template>
<script>
export default {
  name: 'RightToolbar', // 自定义表格工具扩展
  props: {
    showSearch: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {};
  },

  methods: {
    // 搜索
    toggleSearch() {
      this.$emit('update:showSearch', !this.showSearch);
    },
    // 刷新
    refresh() {
      this.$emit('queryTable');
    }
  }
};
</script>
