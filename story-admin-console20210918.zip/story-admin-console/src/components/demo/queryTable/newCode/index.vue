<template>
  <div class="app-container">



  </div>
</template>

<style>

</style>

<script>


export default {

  name: 'newCode',

  // 定义本地过滤器
  filters: {

  },
  // data中存放的是el中需要的数据
  data() {
    return {


    };
  },
  // 侦听属性
  watch: {


  },
  // created 钩子可以用来在一个实例被创建之后执行代码
  created() {},
  // methods是Vue内置的对象，用于存放一些自定义的方法函数
  methods: {


  }
};
</script>
