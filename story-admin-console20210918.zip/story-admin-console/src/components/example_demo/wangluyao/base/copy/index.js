export { default } from './Copy';
