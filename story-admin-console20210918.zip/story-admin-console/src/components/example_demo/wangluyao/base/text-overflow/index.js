export { default } from './TextOverflow'
