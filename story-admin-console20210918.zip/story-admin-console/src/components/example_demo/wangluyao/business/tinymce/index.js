export { default } from './Tinymce';
