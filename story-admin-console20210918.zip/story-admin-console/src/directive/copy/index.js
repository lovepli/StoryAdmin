export { default } from './copy';
