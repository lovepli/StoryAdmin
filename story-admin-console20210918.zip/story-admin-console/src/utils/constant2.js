global.RESULT_SUCCESS_CODE = 20000; // 全局返回数据成功标识位

// 分页用
global.PAGE_SIZES = [20, 40, 60]; // 每页显示条数 选择框数组
global.PAGE_SIZE = 20; // 每页显示条数

// 弹框提示用文本
global.MSGBOX_TITLE_ERROR = '错误提示'; // 弹框标题头
