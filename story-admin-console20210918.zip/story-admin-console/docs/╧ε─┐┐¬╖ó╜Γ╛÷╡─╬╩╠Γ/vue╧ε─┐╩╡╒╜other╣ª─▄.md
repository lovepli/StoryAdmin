Vue+elementUI的动态表单的校验(根据条件动态切换校验格式)
https://segmentfault.com/a/1190000018764875
Vue ElementUi动态表单(多个表单) 的校验及提交
https://segmentfault.com/a/1190000015202475
Vue 多系统切换实现方案(iframe嵌套的两三事)
https://segmentfault.com/a/1190000015167850###
Vue 动态路由的实现(后台传递路由，前端拿到并生成侧边栏)
https://segmentfault.com/a/1190000015419713
手把手带你把vue+webpack 单页面改多页面(适合上手),支持多级目录
https://segmentfault.com/a/1190000017148524