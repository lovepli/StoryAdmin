package com.story.storyadmin.mapper.sysmgr.expand;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.story.storyadmin.domain.entity.sysmgr.Dept;
import com.story.storyadmin.domain.entity.sysmgr.expand.Dept2;

/**
 * @author: lipan
 * @date: 2020/7/31
 * @description:
 */
public interface DeptMapper2 extends BaseMapper<Dept2> {
}
