package com.story.storyadmin.domain.vo.wind;

import lombok.Data;

/**
 * 查询参数对象
 */
@Data
public class CarModelDto {
    private Long carId;
    private String keyword;
}
