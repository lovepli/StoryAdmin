package com.beta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author: lipan
 * @date: 2021年09月27日 11:37 下午
 * @description:
 */
@SpringBootApplication
public class BetaWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(BetaWebApplication.class, args);
    }
}