package com.story.storyadmin.framework.jdkProxyInvocation.invockProxy1;

/**
 * @author: 59688
 * @date: 2021/9/29
 * @description: 业务接口
 */
public interface Man {

    public void findObject() throws Throwable;
}
