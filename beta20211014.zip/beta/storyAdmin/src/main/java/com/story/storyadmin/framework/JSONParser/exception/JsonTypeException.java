package com.story.storyadmin.framework.JSONParser.exception;

/**
 * Created by code4wt on 17/5/11.
 */
public class JsonTypeException extends RuntimeException {

    public JsonTypeException(String message) {
        super(message);
    }
}
