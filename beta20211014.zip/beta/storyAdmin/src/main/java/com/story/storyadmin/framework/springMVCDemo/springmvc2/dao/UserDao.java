package com.story.storyadmin.framework.springMVCDemo.springmvc2.dao;

/**
 * @author: 59688
 * @date: 2021/9/28
 * @description:
 */
public interface UserDao {

    public void  insert();
}
