package com.story.storyadmin.framework.classLoader3;

public class BB {
    private String a;
    public BB(){

    }
    public BB(String a){
        this.a=a;
    }
    public static void main(String[] args) {
        System.out.println("aaaaaaaaaa");
    }
}
