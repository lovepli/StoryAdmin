package com.story.storyadmin.Interceptor.demo1;

/**
 * @author: lipan
 * @date: 2020-05-08
 * @description:  业务组件：分为业务接口和业务类
 */
public interface BusinessInterface {
    public void doSomething();
}
