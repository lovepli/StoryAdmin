package com.story.storyadmin.framework.classLoader.watchfile;

/**
 * @author: 59688
 * @date: 2021/10/14
 * @description:
 */
public interface ITest {

    void test();
}