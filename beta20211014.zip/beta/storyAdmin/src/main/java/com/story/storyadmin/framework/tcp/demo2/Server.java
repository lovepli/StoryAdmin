package com.story.storyadmin.framework.tcp.demo2;

public interface Server {
    public void start();

    public void stop();
}
