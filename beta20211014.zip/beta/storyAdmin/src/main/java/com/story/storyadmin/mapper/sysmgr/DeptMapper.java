package com.story.storyadmin.mapper.sysmgr;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.story.storyadmin.domain.entity.sysmgr.Dept;

/**
 * @author: lipan
 * @date: 2020/7/31
 * @description:
 */
public interface DeptMapper extends BaseMapper<Dept> {
}
