package com.story.storyadmin.enumerator.demo2.enumMethord;

/**
 * @author: lipan
 * @date: 2020-04-26
 * @description: 范型方法
 */
public class Test {


}
