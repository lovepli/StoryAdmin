package com.story.storyadmin.framework.rpcDemo2;

public interface RpcServer {
    public void start();
}