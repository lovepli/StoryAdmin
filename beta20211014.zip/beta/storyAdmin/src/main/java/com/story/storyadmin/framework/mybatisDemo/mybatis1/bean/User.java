package com.story.storyadmin.framework.mybatisDemo.mybatis1.bean;

import lombok.Data;

/**
 * @author: 59688
 * @date: 2021/9/27
 * @description:
 */
@Data
public class User {
    private Long id;
    private String Name;
    private String password;
}
