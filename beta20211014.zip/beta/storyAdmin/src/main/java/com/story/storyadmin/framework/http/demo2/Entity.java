package com.story.storyadmin.framework.http.demo2;

import lombok.Data;

/**
 * @author: 59688
 * @date: 2021/10/14
 * @description:
 */
@Data
public class Entity {

    private String name;
    private String clz;
}
