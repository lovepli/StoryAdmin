package com.story.storyadmin.domain.vo;

import com.story.storyadmin.constant.enumtype.ResultEnum;



/**
 * 响应结果对象
 * @author lipan
 * */
public class ResultUtil {

    // 数据响应成功
    //public static Result success() {
    //    return new Result(true,ResultEnum.TOKEN_CHECK_SUCCESS);
    //}
    //
    //public static Result success(String msg){
    //    return new Result(true,ResultEnum.TOKEN_CHECK_SUCCESS.getCode(),msg)
    //}
}
