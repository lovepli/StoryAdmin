package com.story.storyadmin.framework.http.demo2;

import lombok.Data;

import java.util.List;

/**
 * @author: 59688
 * @date: 2021/10/14
 * @description:
 */
@Data
public class Mapping {

    private String name;

    private List<String> url;

}
