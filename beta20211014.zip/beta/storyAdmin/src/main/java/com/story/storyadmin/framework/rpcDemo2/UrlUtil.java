package com.story.storyadmin.framework.rpcDemo2;

import java.net.URL;

/**
 * @author: 59688
 * @date: 2021/10/13
 * @description:
 */
public class UrlUtil {
    public static URL getLocalUrl() {
        return null;
    }
}
