package com.story.storyadmin.framework.rpcDemo2;

/**
 * @author: 59688
 * @date: 2021/10/13
 * @description:
 */
public class MyFirstService {
}
