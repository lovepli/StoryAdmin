package com.story.storyadmin.domain.entity.children.myBatisTypeHandlerDO;

import lombok.Data;
import lombok.ToString;

/**
 * @author: lipan
 * @date: 2021年09月08日 2:35 下午
 * @description:
 */
@Data
@ToString
public class PersonDO {
    private String name;
    private int age;
}
