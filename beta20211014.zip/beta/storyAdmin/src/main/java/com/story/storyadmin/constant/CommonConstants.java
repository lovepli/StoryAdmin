package com.story.storyadmin.constant;

/**
 * @author: 59688
 * @date: 2021/7/5
 * @description:
 */
public class CommonConstants {

    /**********************定义魔数 是否删除，直接在xml文件中引用，方便维护***********************/
    // 删除
    public static final String DELETE = "0";
    // 不删除
    public static final String NOT_DELETE = "1";
}
