package com.story.storyadmin.domain.vo.wind;

import lombok.Data;

@Data
public class CarDto {

    private String keyword;

}
