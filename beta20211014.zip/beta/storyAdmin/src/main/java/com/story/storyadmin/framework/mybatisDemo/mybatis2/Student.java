package com.story.storyadmin.framework.mybatisDemo.mybatis2;

import lombok.Data;

/**
 * @author: 59688
 * @date: 2021/9/28
 * @description:
 */
@Data
public class Student {

    private int id;

    private int sex;

    private String Name;

    private  int age;

    private  String address;
}
