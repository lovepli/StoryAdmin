package com.story.storyadmin.framework.springMVCDemo.springmvc2.service;

/**
 * @author: 59688
 * @date: 2021/9/28
 * @description:
 */
public interface UserService {

    public void insert();
}
