package com.story.storyadmin.jsonUtil.jacksonUtil.groups;

import javax.validation.groups.Default;

public interface Update extends Default {
}