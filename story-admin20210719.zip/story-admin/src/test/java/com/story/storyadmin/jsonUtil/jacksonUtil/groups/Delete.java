package com.story.storyadmin.jsonUtil.jacksonUtil.groups;

import javax.validation.groups.Default;

public interface Delete extends Default {
}