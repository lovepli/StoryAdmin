package com.story.storyadmin.domain.entity.children;

import junit.framework.TestCase;

public class DTeacherTest extends TestCase {

}