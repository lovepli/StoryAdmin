package com.story.storyadmin.jsonUtil.jacksonUtil.groups;

import javax.validation.groups.Default;

/**
 * @author lipan
 */
public interface Create extends Default {
}