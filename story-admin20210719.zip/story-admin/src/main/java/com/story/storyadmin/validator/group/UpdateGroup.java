package com.story.storyadmin.validator.group;

/**
 * 
 * @ClassName: UpdateGroup   
 * @Description: 更新数据 Group
 * @author: liutao
 * @date: 2018年3月16日 下午2:29:34
 */
public interface UpdateGroup {

}
