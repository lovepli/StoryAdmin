package com.story.storyadmin.validator.group2;

/**
 * @author: 59688
 * @date: 2021/7/15
 * @description: 分组校验
 */
public interface  GroupB {
}
