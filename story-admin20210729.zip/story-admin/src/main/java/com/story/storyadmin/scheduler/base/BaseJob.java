package com.story.storyadmin.scheduler.base;

import org.quartz.Job;

/**
 * 自定义一个我们自己的Job抽象父类，实现quartz定时任务job接口
 */
public abstract class BaseJob implements Job {

}
