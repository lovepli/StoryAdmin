package com.story.storyadmin.domain.vo.wind;

import lombok.Data;

@Data
public class TreeAndTableDto {


    private String name;  //部门名称

    private String type;  //类型

    private String areaId;  //区域
}
