package com.story.storyadmin.Interceptor;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author: 59688
 * @date: 2021/7/28
 * @description: 一个注解搞定 SpringBoot 接口防刷，还有谁不会？ https://mp.weixin.qq.com/s/KlMGqFOqiTMDdtQ_7WYuwg
 */
@Retention(RUNTIME)
@Target(METHOD)
public @interface AccessLimit {

    int seconds();
    int maxCount();
    boolean needLogin()default true;
}
