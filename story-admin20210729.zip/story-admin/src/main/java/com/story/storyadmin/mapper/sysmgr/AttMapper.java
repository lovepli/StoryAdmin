package com.story.storyadmin.mapper.sysmgr;

import com.story.storyadmin.domain.entity.sysmgr.Att;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 附件表 Mapper 接口
 * </p>
 *
 * @author sunnj
 * @since 2019-07-12
 */
public interface AttMapper extends BaseMapper<Att> {

}
