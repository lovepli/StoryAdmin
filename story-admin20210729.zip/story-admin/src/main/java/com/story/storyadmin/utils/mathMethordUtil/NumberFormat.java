package com.story.storyadmin.utils.mathMethordUtil;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * @author: lipan
 * @date: 2020/6/9
 * @description: BigDecimal格式化
 */
public class NumberFormat {

    private void fun(){
        NumberFormat currency = NumberFormat.getCurrencyInstance(); //建立货币格式化引用
        NumberFormat percent = NumberFormat.getPercentInstance();  //建立百分比格式化引用
        percent.setMaximumFractionDigits(3); //百分比小数点最多3位

        BigDecimal loanAmount = new BigDecimal("15000.48"); //贷款金额
        BigDecimal interestRate = new BigDecimal("0.008"); //利率
        BigDecimal interest = loanAmount.multiply(interestRate); //相乘

        System.out.println("贷款金额:\t" + currency.format(loanAmount));
        System.out.println("利率:\t" + percent.format(interestRate));
        System.out.println("利息:\t" + currency.format(interest));
    }

    private void setMaximumFractionDigits(int i) {
    }

    private static NumberFormat getPercentInstance() {
        return new NumberFormat();
    }

    private static NumberFormat getCurrencyInstance() {
        return new NumberFormat();
    }

    private String format(BigDecimal bigDecimal){
        return "";
    }


    public static void main(String[] s){
        System.out.println(formatToNumber(new BigDecimal("3.435")));
        System.out.println(formatToNumber(new BigDecimal(0)));
        System.out.println(formatToNumber(new BigDecimal("0.00")));
        System.out.println(formatToNumber(new BigDecimal("0.001")));
        System.out.println(formatToNumber(new BigDecimal("0.006")));
        System.out.println(formatToNumber(new BigDecimal("0.206")));
    }
    /**
     * @desc 1.0~1之间的BigDecimal小数，格式化后失去前面的0,则前面直接加上0。
     * 2.传入的参数等于0，则直接返回字符串"0.00"
     * 3.大于1的小数，直接格式化返回字符串
     * @param obj 传入的小数
     * @return
     */
    public static String formatToNumber(BigDecimal obj) {
        DecimalFormat df = new DecimalFormat("#.00");
        if(obj.compareTo(BigDecimal.ZERO)==0) {
            return "0.00";
        }else if(obj.compareTo(BigDecimal.ZERO)>0&&obj.compareTo(new BigDecimal(1))<0){
            return "0"+df.format(obj).toString();
        }else {
            return df.format(obj).toString();
        }
    }

    //TODO 避免使用BigDecimal(double)
    //
    //BigDecimal(double) 存在精度损失风险，在精确计算或值比较的场景中可能会导致业务逻辑异常。
    //
    //反例：
    //BigDecimal 反例
    //BigDecimal bigDecimal = new BigDecimal(0.11D);
    //
    //正例：
    // BigDecimal 正例
    //BigDecimal bigDecimal1 = bigDecimal.valueOf(0.11D);
}
