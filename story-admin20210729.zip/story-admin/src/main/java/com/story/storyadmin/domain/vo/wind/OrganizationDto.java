package com.story.storyadmin.domain.vo.wind;

import lombok.Data;

@Data
public class OrganizationDto {

    private String keyword;

}
